package contact;

public class ContactServiceTest {

}
