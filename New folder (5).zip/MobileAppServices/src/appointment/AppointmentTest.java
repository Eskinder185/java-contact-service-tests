package appointment;

public class AppointmentTest {

}
