package appointment;

public class AppointmentServiceTest {

}
